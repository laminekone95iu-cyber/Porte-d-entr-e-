import { useEffect, useRef, useState } from "react";

/* @section: video-url */
const VIDEO_URL =
  "https://skyagent-artifacts.skywork.ai/router/agent/2026-06-16/prod_agent_faf53457-3916-40a6-92b8-7afb553b4cfc/361749803_1781104025125492_555b72a166b64c648e6bb49295ed12c0.mp4";

/* @section: matrix-rain */
function MatrixRain() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener("resize", resize);
    const fontSize = 14;
    const chars =
      "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ∞∑∫√πeΔ";
    const columns = () => Math.floor(canvas.width / fontSize);
    let drops: number[] = Array(columns()).fill(1);
    let expBase: number[] = drops.map((_, i) => 1 + (i % 7) * 0.08);
    let speeds: number[] = drops.map((_, i) => 0.5 + Math.pow(1.04, i % 20) * 0.4);
    let frame = 0;
    const draw = () => {
      ctx.fillStyle = "rgba(0,0,0,0.048)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < drops.length; i++) {
        const char = chars[Math.floor(Math.random() * chars.length)];
        const x = i * fontSize;
        const y = drops[i] * fontSize;
        const expFactor = Math.min(Math.pow(expBase[i], (frame % 200) * 0.01), 2.5);
        const brightness = Math.floor(Math.min(expFactor * 80, 255));
        const isHead = Math.random() > 0.975;
        if (isHead) {
          ctx.fillStyle = "rgba(255,255,255,0.95)";
        } else if (drops[i] > (canvas.height / fontSize) * 0.7) {
          ctx.fillStyle = `rgba(255,${Math.floor(brightness * 1.3)},0,${0.3 + expFactor * 0.1})`;
        } else {
          ctx.fillStyle = `rgba(0,${brightness + 130},65,${0.65 + Math.random() * 0.35})`;
        }
        ctx.font = `${fontSize}px 'Courier New',monospace`;
        ctx.fillText(char, x, y);
        const resetProb = 0.975 - Math.pow(speeds[i] * 0.001, 0.5) * 0.02;
        if (y > canvas.height && Math.random() > resetProb) drops[i] = 0;
        drops[i] += speeds[i] * 0.08;
      }
      frame++;
    };
    const interval = setInterval(draw, 35);
    return () => {
      clearInterval(interval);
      window.removeEventListener("resize", resize);
    };
  }, []);
  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed", top: 0, left: 0, width: "100%", height: "100%",
        zIndex: 2, mixBlendMode: "screen", pointerEvents: "none",
      }}
    />
  );
}

/* @section: exponential-graph */
function ExponentialGraph() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    let t = 0;
    let rafId: number;
    const curves = [
      { base: Math.E, color: "#00FF41", alpha: 0.9, label: "e\u02e3" },
      { base: 1.5, color: "#FFD700", alpha: 0.7, label: "1.5\u02e3" },
      { base: 2, color: "#00BFFF", alpha: 0.6, label: "2\u02e3" },
    ];
    const animate = () => {
      ctx.clearRect(0, 0, W, H);
      curves.forEach(({ base, color, alpha, label }, ci) => {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.globalAlpha = alpha;
        ctx.lineWidth = 1.5;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        for (let x = 0; x < W; x++) {
          const xNorm = (x / W) * 4 + t * 0.002 - 2;
          const y = H - (Math.pow(base, xNorm) / Math.pow(base, 2)) * H * 0.85;
          x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, Math.max(0, Math.min(H, y)));
        }
        ctx.stroke();
        ctx.globalAlpha = 0.7;
        ctx.fillStyle = color;
        ctx.font = "10px 'Courier New'";
        ctx.shadowBlur = 0;
        ctx.fillText(label, W - 28, 14 + ci * 14);
      });
      ctx.globalAlpha = 1;
      ctx.strokeStyle = "rgba(0,255,65,0.3)";
      ctx.lineWidth = 0.5;
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.moveTo(0, H * 0.85); ctx.lineTo(W, H * 0.85);
      ctx.moveTo(W * 0.05, 0); ctx.lineTo(W * 0.05, H);
      ctx.stroke();
      t++;
      rafId = requestAnimationFrame(animate);
    };
    rafId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafId);
  }, []);
  return (
    <canvas
      ref={canvasRef}
      width={220}
      height={100}
      style={{
        border: "1px solid rgba(0,255,65,0.25)", borderRadius: "4px",
        background: "rgba(0,0,0,0.5)", display: "block",
      }}
    />
  );
}

/* @section: glitch-text */
function GlitchText({ text }: { text: string }) {
  const [glitch, setGlitch] = useState(false);
  useEffect(() => {
    const iv = setInterval(() => {
      setGlitch(true);
      setTimeout(() => setGlitch(false), 180);
    }, 2800 + Math.random() * 2000);
    return () => clearInterval(iv);
  }, []);
  return (
    <span style={{ position: "relative", display: "inline-block", animation: glitch ? "glitch 0.18s steps(2) infinite" : "none" }}>
      {text}
      {glitch && (
        <>
          <span style={{ position: "absolute", top: 0, left: "2px", color: "#FF0066", clipPath: "inset(30% 0 50% 0)", opacity: 0.85 }}>{text}</span>
          <span style={{ position: "absolute", top: 0, left: "-2px", color: "#00FFFF", clipPath: "inset(60% 0 20% 0)", opacity: 0.85 }}>{text}</span>
        </>
      )}
    </span>
  );
}

/* @section: counter */
function Counter() {
  const [val, setVal] = useState(0);
  const [idx, setIdx] = useState(0);
  const labels = ["INITIATING SEQUENCE","DECODING REALITY","OPENING PARADISE GATES","VIE OU DÉFI — CHOOSE","∞ EXPONENTIAL ASCENSION ∞"];
  useEffect(() => {
    let i = 0;
    const iv = setInterval(() => {
      setVal(Math.floor(Math.pow(Math.E, i * 0.18) * 100) % 1000);
      setIdx(i % labels.length);
      i++;
    }, 1200);
    return () => clearInterval(iv);
  }, []);
  return (
    <div style={{ fontFamily: "monospace", color: "#00FF41", fontSize: "11px", letterSpacing: "0.15em" }}>
      <span style={{ color: "#FFD700" }}>[</span>{String(val).padStart(4, "0")}<span style={{ color: "#FFD700" }}>]</span>{" "}
      <span style={{ opacity: 0.75 }}>{labels[idx]}</span>
    </div>
  );
}

/* @section: stats-panel */
function StatsPanel() {
  const [stats, setStats] = useState({ nodes: 0, power: 0, ascension: 0 });
  useEffect(() => {
    let t = 0;
    const iv = setInterval(() => {
      setStats({
        nodes: Math.floor(Math.pow(Math.E, t * 0.05) * 144) % 99999,
        power: Math.floor(Math.pow(2, t * 0.03) * 10) % 9999,
        ascension: Math.floor(Math.min(Math.pow(1.08, t), 100)),
      });
      t++;
    }, 600);
    return () => clearInterval(iv);
  }, []);
  const items = [
    { label: "NODES ACTIVE", val: stats.nodes.toString().padStart(5, "0"), unit: "" },
    { label: "DIVINE POWER", val: stats.power.toString().padStart(4, "0"), unit: "kW" },
    { label: "ASCENSION", val: stats.ascension.toString().padStart(3, "0"), unit: "%" },
    { label: "e^∞ FACTOR", val: "∞", unit: "" },
  ];
  return (
    <div style={{ background: "rgba(0,0,0,0.72)", border: "1px solid rgba(0,255,65,0.3)", borderRadius: "6px", padding: "12px 16px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", backdropFilter: "blur(4px)" }}>
      {items.map((item) => (
        <div key={item.label}>
          <div style={{ color: "rgba(0,255,65,0.55)", fontSize: "9px", letterSpacing: "0.12em", fontFamily: "monospace" }}>{item.label}</div>
          <div style={{ color: "#00FF41", fontSize: "22px", fontFamily: "monospace", fontWeight: "bold", textShadow: "0 0 8px #00FF41" }}>
            {item.val}<span style={{ fontSize: "10px", color: "#FFD700", marginLeft: "3px" }}>{item.unit}</span>
          </div>
        </div>
      ))}
    </div>
  );
}

/* @section: code-log */
function CodeLog() {
  const lines = [
    "> BOOT divine_sector.exe","‌> LOADING bab_al_jannah.dat ...","‌> e^∞ = PARADISE UNLOCKED",
    "> MATRIX rain: ACTIVE [100%]","‌> NODES: 144 × e^7 connected","‌> EXPONENTIAL: f(x)=eˣ READY",
    "> STATUS: VIE OU DÉFI [GO]","‌> DIVINE LIGHT: OUTPUT 9999kW","‌> SCAN: all_souls.matrix OK",
    "> CHOICE: RED or GOLD pill?","‌> JANNAH gate: OPEN ✓","‌> ASCENSION: 100% complete ∞",
  ];
  const [visible, setVisible] = useState(0);
  const [typed, setTyped] = useState("");
  useEffect(() => {
    let lineIdx = 0, charIdx = 0;
    const iv = setInterval(() => {
      if (lineIdx >= lines.length) { lineIdx = 0; setVisible(0); setTyped(""); }
      const target = lines[lineIdx];
      if (charIdx <= target.length) { setTyped(target.slice(0, charIdx)); charIdx++; }
      else { charIdx = 0; lineIdx++; setVisible((v) => Math.min(v + 1, lines.length - 1)); }
    }, 35);
    return () => clearInterval(iv);
  }, []);
  return (
    <div style={{ background: "rgba(0,0,0,0.78)", border: "1px solid rgba(0,255,65,0.25)", borderRadius: "6px", padding: "12px 14px", height: "200px", overflowY: "hidden", backdropFilter: "blur(4px)", display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
      {lines.slice(Math.max(0, visible - 8), visible).map((line, i) => (
        <div key={i} style={{ color: (line.includes("PARADISE")||line.includes("JANNAH")||line.includes("DIVINE")) ? "rgba(255,215,0,0.75)" : "rgba(0,255,65,0.55)", fontSize: "10px", lineHeight: "1.7", fontFamily: "monospace", letterSpacing: "0.06em" }}>
          {line}
        </div>
      ))}
      <div style={{ color: "#00FF41", fontSize: "10px", fontFamily: "monospace", lineHeight: "1.7" }}>
        {typed}<span style={{ animation: "blink 0.8s infinite" }}>█</span>
      </div>
    </div>
  );
}

/* @section: app-root */
export default function App() {
  const [entered, setEntered] = useState(false);
  const [opacity, setOpacity] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  useEffect(() => { setTimeout(() => setOpacity(1), 100); }, []);
  const handleEnter = () => {
    setEntered(true);
    videoRef.current?.play().catch(() => {});
  };

  return (
    <div style={{ position: "relative", width: "100vw", minHeight: "100vh", background: "#000", overflow: "hidden", fontFamily: "'Courier New',Courier,monospace", transition: "opacity 1.2s ease", opacity }}>

      {/* @section: video-background */}
      <video ref={videoRef} src={VIDEO_URL} autoPlay muted loop playsInline
        style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", minWidth: "100%", minHeight: "100%", width: "auto", height: "auto", objectFit: "cover", zIndex: 1, opacity: entered ? 0.52 : 0.18, transition: "opacity 2.5s ease", filter: "saturate(1.15) brightness(0.75) contrast(1.1)" }}
      />

      {/* @section: matrix-overlay */}
      <MatrixRain />

      {/* @section: vignette */}
      <div style={{ position: "fixed", inset: 0, zIndex: 3, background: "radial-gradient(ellipse 60% 50% at 50% 50%, transparent 30%, rgba(0,0,0,0.35) 70%, rgba(0,0,0,0.72) 100%)", pointerEvents: "none" }} />

      {/* @section: divine-pulse */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", width: "40vw", height: "40vw", borderRadius: "50%", background: "radial-gradient(circle, rgba(255,215,0,0.07) 0%, transparent 70%)", zIndex: 3, pointerEvents: "none", animation: "pulse-gold 4s ease-in-out infinite" }} />

      {/* @section: main-content */}
      <div style={{ position: "relative", zIndex: 10, display: "flex", flexDirection: "column", alignItems: "center", minHeight: "100vh", padding: "0 20px" }}>

        {/* @section: header-bar */}
        <div style={{ width: "100%", maxWidth: "900px", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 0 10px", borderBottom: "1px solid rgba(0,255,65,0.18)", flexWrap: "wrap", gap: "8px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#00FF41", boxShadow: "0 0 10px #00FF41", animation: "blink 1.2s infinite" }} />
            <span style={{ color: "rgba(0,255,65,0.7)", fontSize: "11px", letterSpacing: "0.2em" }}>SYSTEM ONLINE</span>
          </div>
          <Counter />
          <div style={{ color: "rgba(0,255,65,0.5)", fontSize: "10px", letterSpacing: "0.1em" }}>MATRIX_PROTOCOL v2.∞</div>
        </div>

        {/* @section: hero-title */}
        <div style={{ textAlign: "center", marginTop: "clamp(30px,6vh,70px)", marginBottom: "20px" }}>
          <div style={{ color: "rgba(0,255,65,0.6)", fontSize: "clamp(10px,1.3vw,14px)", letterSpacing: "0.35em", marginBottom: "14px" }}>
            ▸ MATRIX PROTOCOL — DIVINE SECTOR ◂
          </div>
          <h1 style={{ margin: 0, fontSize: "clamp(42px,7.5vw,88px)", fontWeight: 900, letterSpacing: "0.05em", lineHeight: 1.05, color: "#00FF41", textShadow: "0 0 30px rgba(0,255,65,0.5)" }}>
            <GlitchText text="MATRIX" />
            <br />
            <span style={{ background: "linear-gradient(135deg,#FFD700 0%,#FFA500 40%,#FFFFFF 60%,#FFD700 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text", filter: "drop-shadow(0 0 18px rgba(255,215,0,0.6))" }}>
              VIE OU DÉFI
            </span>
          </h1>
          <div style={{ marginTop: "16px", color: "rgba(0,255,65,0.55)", fontSize: "clamp(11px,1.5vw,15px)", letterSpacing: "0.28em" }}>
            بَابُ الْجَنَّةِ &nbsp;·&nbsp; f(x) = eˣ &nbsp;·&nbsp; ∞ ASCENSION PROTOCOL ∞
          </div>
        </div>

        {/* @section: enter-gate */}
        {!entered && (
          <button onClick={handleEnter}
            style={{ marginTop: "20px", background: "transparent", border: "1px solid rgba(0,255,65,0.6)", color: "#00FF41", fontSize: "13px", letterSpacing: "0.3em", padding: "12px 40px", cursor: "pointer", fontFamily: "monospace", transition: "all 0.3s", boxShadow: "0 0 20px rgba(0,255,65,0.15),inset 0 0 20px rgba(0,255,65,0.05)", animation: "border-pulse 2s ease-in-out infinite" }}
            onMouseEnter={e => { const b = e.currentTarget; b.style.background="rgba(0,255,65,0.1)"; b.style.boxShadow="0 0 40px rgba(0,255,65,0.4)"; }}
            onMouseLeave={e => { const b = e.currentTarget; b.style.background="transparent"; b.style.boxShadow="0 0 20px rgba(0,255,65,0.15)"; }}
          >
            ▸ ENTER THE GATE ◂
          </button>
        )}

        {/* @section: main-grid */}
        <div style={{ width: "100%", maxWidth: "900px", display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))", gap: "20px", marginTop: "clamp(20px,4vh,50px)" }}>

          {/* @section: panel-stats */}
          <div>
            <div style={{ color: "rgba(0,255,65,0.55)", fontSize: "9px", letterSpacing: "0.2em", marginBottom: "8px" }}>▸ LIVE MATRIX METRICS</div>
            <StatsPanel />
          </div>

          {/* @section: panel-graph */}
          <div>
            <div style={{ color: "rgba(255,215,0,0.65)", fontSize: "9px", letterSpacing: "0.2em", marginBottom: "8px" }}>▸ INGRÉDIENT SECRET — COURBES EXPONENTIELLES eˣ</div>
            <ExponentialGraph />
            <div style={{ marginTop: "10px", background: "rgba(0,0,0,0.72)", border: "1px solid rgba(255,215,0,0.2)", borderRadius: "6px", padding: "10px 14px", backdropFilter: "blur(4px)" }}>
              {[["f(x) = eˣ","#00FF41","GROWTH INFINITE"],["f(x) = 2ˣ","#00BFFF","DIGITAL EXPANSION"],["f(x) = 1.5ˣ","#FFD700","DIVINE COMPOUND"]].map(([eq,c,lab])=>(
                <div key={eq} style={{ color: "rgba(255,215,0,0.8)", fontSize: "10px", lineHeight: "1.7" }}>
                  {eq} &nbsp;<span style={{ color: c }}>{lab}</span>
                </div>
              ))}
            </div>
          </div>

          {/* @section: panel-code */}
          <div>
            <div style={{ color: "rgba(0,255,65,0.55)", fontSize: "9px", letterSpacing: "0.2em", marginBottom: "8px" }}>▸ SYSTEM LOG — PARADISE PROTOCOL</div>
            <CodeLog />
          </div>
        </div>

        {/* @section: quote-bar */}
        <div style={{ width: "100%", maxWidth: "900px", margin: "clamp(20px,4vh,45px) 0", padding: "18px 24px", background: "rgba(0,0,0,0.65)", border: "1px solid rgba(255,215,0,0.22)", borderLeft: "3px solid rgba(255,215,0,0.7)", backdropFilter: "blur(6px)" }}>
          <div style={{ color: "rgba(255,215,0,0.85)", fontSize: "clamp(12px,1.5vw,16px)", letterSpacing: "0.08em", lineHeight: "1.8", textAlign: "center", fontStyle: "italic" }}>
            "Dans la <span style={{ color: "#00FF41", fontStyle: "normal" }}>MATRICE</span>, chaque choix trace une courbe exponentielle —{" "}
            <span style={{ color: "#FFD700" }}>VIE ou DÉFI</span> — vers les portes de <span style={{ color: "#FFFFFF" }}>الجنة</span>"
          </div>
        </div>

        {/* @section: footer-nav */}
        <div style={{ width: "100%", maxWidth: "900px", display: "flex", justifyContent: "center", gap: "clamp(16px,3vw,40px)", padding: "16px 0 30px", borderTop: "1px solid rgba(0,255,65,0.12)", flexWrap: "wrap" }}>
          {["VIE","DÉFI","MATRICE","PARADIS","∞"].map((item) => (
            <button key={item} style={{ background: "transparent", border: "none", color: "rgba(0,255,65,0.55)", fontSize: "11px", letterSpacing: "0.25em", cursor: "pointer", fontFamily: "monospace", transition: "color 0.25s,text-shadow 0.25s", padding: "4px 8px" }}
              onMouseEnter={e => { const b=e.currentTarget; b.style.color="#FFD700"; b.style.textShadow="0 0 12px #FFD700"; }}
              onMouseLeave={e => { const b=e.currentTarget; b.style.color="rgba(0,255,65,0.55)"; b.style.textShadow="none"; }}
            >{item}</button>
          ))}
        </div>
      </div>

      {/* @section: keyframes */}
      <style>{`
        @keyframes blink { 0%,100%{opacity:1}50%{opacity:0.15} }
        @keyframes pulse-gold { 0%,100%{transform:translate(-50%,-50%) scale(1);opacity:0.6}50%{transform:translate(-50%,-50%) scale(1.3);opacity:1} }
        @keyframes border-pulse { 0%,100%{box-shadow:0 0 20px rgba(0,255,65,0.15),inset 0 0 20px rgba(0,255,65,0.05)}50%{box-shadow:0 0 35px rgba(0,255,65,0.35),inset 0 0 30px rgba(0,255,65,0.12)} }
        @keyframes glitch { 0%{transform:translate(0)}25%{transform:translate(-2px,1px) skewX(-2deg)}50%{transform:translate(2px,-1px) skewX(2deg)}75%{transform:translate(-1px,2px)}100%{transform:translate(0)} }
        *{box-sizing:border-box}
        body{margin:0;padding:0;background:#000}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-track{background:#000}
        ::-webkit-scrollbar-thumb{background:rgba(0,255,65,0.4);border-radius:2px}
      `}</style>
    </div>
  );
}
